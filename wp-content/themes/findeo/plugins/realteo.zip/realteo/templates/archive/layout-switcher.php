<div class="col-md-6">
	<!-- Layout Switcher -->
	<div class="layout-switcher">
		<a href="#" id="list-layout" class="list"><i class="fa fa-th-list"></i></a>
		<a href="#" id="grid-layout" class="grid"><i class="fa fa-th-large"></i></a>
		<a href="#"  id="grid-three" class="grid-three"><i class="fa fa-th"></i></a>
	</div>
</div>
<!-- Sorting / Layout Switcher -->